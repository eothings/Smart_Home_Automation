/******************************************************************************
* File Name:   tcp_client.c
*
* Description: This file contains task and functions related to TCP client
* operation.
*
*******************************************************************************
* (c) 2019-2020, Cypress Semiconductor Corporation. All rights reserved.
*******************************************************************************
* This software, including source code, documentation and related materials
* ("Software"), is owned by Cypress Semiconductor Corporation or one of its
* subsidiaries ("Cypress") and is protected by and subject to worldwide patent
* protection (United States and foreign), United States copyright laws and
* international treaty provisions. Therefore, you may use this Software only
* as provided in the license agreement accompanying the software package from
* which you obtained this Software ("EULA").
*
* If no EULA applies, Cypress hereby grants you a personal, non-exclusive,
* non-transferable license to copy, modify, and compile the Software source
* code solely for use in connection with Cypress's integrated circuit products.
* Any reproduction, modification, translation, compilation, or representation
* of this Software except as specified above is prohibited without the express
* written permission of Cypress.
*
* Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Cypress
* reserves the right to make changes to the Software without notice. Cypress
* does not assume any liability arising out of the application or use of the
* Software or any product or circuit described in the Software. Cypress does
* not authorize its products for use in any products where a malfunction or
* failure of the Cypress product may reasonably be expected to result in
* significant property damage, injury or death ("High Risk Product"). By
* including Cypress's product in a High Risk Product, the manufacturer of such
* system or application assumes all risk of such use and in doing so agrees to
* indemnify Cypress against all liability.
*******************************************************************************/

/* Header file includes. */
#include "cyhal.h"
#include "cybsp.h"
#include "cy_retarget_io.h"

/* FreeRTOS header file. */
#include <FreeRTOS.h>
#include <task.h>
#include <semphr.h>

/* Standard C header file. */
#include <string.h>

///* Cypress secure socket header file. */
//#include "cy_secure_sockets.h"

/* Wi-Fi connection manager header files. */
#include "cy_wcm.h"
#include "cy_wcm_error.h"

/* TCP client task header file. */
#include "tcp_client.h"
/*******************************************************************************
* Macros
********************************************************************************/
/* Maximum number of connection retries to the TCP server. */
#define MAX_TCP_SERVER_CONN_RETRIES        (5u)

/* Length of the TCP data packet. */
//#define MAX_TCP_DATA_PACKET_LENGTH         (20)

/* Length of the LED ON/OFF command issued from the TCP server. */
//#define TCP_LED_CMD_LEN                    (1)
//#define LED_ON_CMD                         '1'
//#define LED_OFF_CMD                        '0'
//#define ACK_LED_ON                         "LED ON ACK"
//#define ACK_LED_OFF                        "LED OFF ACK"
//#define MSG_INVALID_CMD                    "Invalid command"

//#define v0(x) sprintf(v0,"vw\00\0%2.2f",x)
//#define BLYNK_STRINGIFY(x) #x
//#define BLYNK_TOSTRING(x) BLYNK_STRINGIFY(x)
//#define BLYNK_PARAM_KV(k, v) k "\0" v "\0"
//char info[] =   BLYNK_PARAM_KV("ver"    , BLYNK_VERSION)BLYNK_PARAM_KV("h-beat" , BLYNK_TOSTRING(BLYNK_HEARTBEAT))BLYNK_PARAM_KV("buff-in", BLYNK_TOSTRING(BLYNK_MAX_READBYTES));

// union data
// {
//	 bool state;
//	 uint16_t i;
//	 char c[4];
//}val;

uint8_t blynkState = disconnected;
uint8_t blynkInit = _start;
static uint16_t msg_id=0;
/*******************************************************************************/
#if (FLASH_REGION_TO_USE)
CY_SECTION(".cy_em_eeprom")
#endif /* #if(FLASH_REGION_TO_USE) */
CY_ALIGN(CY_EM_EEPROM_FLASH_SIZEOF_ROW)

const uint8_t EepromStorage[CY_EM_EEPROM_GET_PHYSICAL_SIZE(EEPROM_SIZE,
SIMPLE_MODE, WEAR_LEVELLING_FACTOR, REDUNDANT_COPY)] = {0u};

/* EEPROM configuration and context structure. */
cy_stc_eeprom_config_t Em_EEPROM_config =
{
    .eepromSize = EEPROM_SIZE,
    .blockingWrite = BLOCKING_WRITE,
    .redundantCopy = REDUNDANT_COPY,
    .wearLevelingFactor = WEAR_LEVELLING_FACTOR,
    .userFlashStartAddr = (uint32_t)EepromStorage,
};

cy_stc_eeprom_context_t Em_EEPROM_context;
blynk_details_t blynk_details;
/*******************************************************************************
* Function Prototypes
********************************************************************************/
cy_rslt_t create_tcp_client_socket();
cy_rslt_t tcp_client_recv_handler(cy_socket_t socket_handle, void *arg);
cy_rslt_t tcp_disconnection_handler(cy_socket_t socket_handle, void *arg);
cy_rslt_t connect_to_tcp_server(cy_socket_sockaddr_t address);
cy_rslt_t connect_to_wifi_ap(void);
void msg_frame(uint8_t cmd, char* data);
void decode(void);
void blynk_mstimer_cb(TimerHandle_t timer_handle);
void blynk_txtimer_cb(TimerHandle_t timer_handle);
cy_rslt_t start_blynk_session(void);
/*******************************************************************************
* Global Variables
********************************************************************************/
/* TCP client socket handle */
cy_socket_t client_handle;
/* Binary semaphore handle to keep track of TCP server connection. */
SemaphoreHandle_t connect_to_server;

static TimerHandle_t blynk_mstimer, blynk_txtimer;
//BlynkSimple* Blynk;
extern struct VirtualWrite vw;
extern volatile uint32_t msec;
extern struct ProtocolHeader ph;

/*******************************************************************************
 * Function Name: tcp_client_task
 *******************************************************************************
 * Summary:
 *  Task used to establish a connection to a remote TCP server and
 *  control the LED state (ON/OFF) based on the command received from TCP server.
 *
 * Parameters:
 *  void *args : Task parameter defined during task creation (unused).
 *
 * Return:
 *  void
 *
 *******************************************************************************/
void tcp_client_task(void *arg)
{
    cy_rslt_t result ;

    /* IP address and TCP port number of the TCP server to which the TCP client
     * connects to. 
     */
//    cy_socket_sockaddr_t tcp_server_address =
//    {
//        .ip_address.ip.v4 = TCP_SERVER_IP_ADDRESS,
//        .ip_address.version = CY_SOCKET_IP_VER_V4,
//        .port = TCP_SERVER_PORT
//    };
    cy_socket_sockaddr_t tcp_server_address;

	tcp_server_address.ip_address.ip.v4 = TCP_SERVER_IP_ADDRESS;
	tcp_server_address.ip_address.version = CY_SOCKET_IP_VER_V4;
	tcp_server_address.port = TCP_SERVER_PORT;

//    printf("tcp_client_task\n");
    /* Create a binary semaphore to keep track of TCP server connection. */
    connect_to_server = xSemaphoreCreateBinary();

    /* Give the semaphore so as to connect to TCP server.  */
    xSemaphoreGive(connect_to_server);

    /* Connect to Wi-Fi AP */
    if(connect_to_wifi_ap() != CY_RSLT_SUCCESS )
    {
        printf("\n Failed to connect to Wi-FI AP.\n");
        CY_ASSERT(0);
    }

    /* Initialize secure socket library. */
    result = cy_socket_init();
    if (result != CY_RSLT_SUCCESS)
    {
        printf("Secure Socket initialization failed!\n");
        CY_ASSERT(0);
    }
    printf("Secure Socket initialized\n");


    /*   create blynk 1ms timer */
    blynk_mstimer = xTimerCreate("blynk_mstimer", pdMS_TO_TICKS(1), pdTRUE, NULL, blynk_mstimer_cb);

    /*   create blynk 10sec tx timer */
    blynk_txtimer = xTimerCreate("blynk_txtimer", pdMS_TO_TICKS(1000), pdTRUE, NULL, blynk_txtimer_cb);


    for(;;)
    {
        /* Wait till semaphore is acquired so as to connect to a TCP server. */
        xSemaphoreTake(connect_to_server, portMAX_DELAY);

        /* Connect to the TCP server. If the connection fails, retry
         * to connect to the server for MAX_TCP_SERVER_CONN_RETRIES times.
         */
        printf("Connecting to TCP server...\n");
        result = connect_to_tcp_server(tcp_server_address);

        if(result != CY_RSLT_SUCCESS)
        {
            printf("Failed to connect to TCP server.\n");
            CY_ASSERT(0);
        }
    }
 }

/*******************************************************************************
 * Function Name: connect_to_wifi_ap()
 *******************************************************************************
 * Summary:
 *  Connects to Wi-Fi AP using the user-configured credentials, retries up to a
 *  configured number of times until the connection succeeds.
 *
 *******************************************************************************/
cy_rslt_t connect_to_wifi_ap(void)
{
    cy_rslt_t result;

    /* Variables used by Wi-Fi connection manager.*/
    cy_wcm_connect_params_t wifi_conn_param;

    cy_wcm_config_t wifi_config = { .interface = CY_WCM_INTERFACE_TYPE_STA };

    cy_wcm_ip_address_t ip_address;
//    printf("connect_to_wifi_ap\n");
     /* Initialize Wi-Fi connection manager. */
    result = cy_wcm_init(&wifi_config);

    if (result != CY_RSLT_SUCCESS)
    {
        printf("Wi-Fi Connection Manager initialization failed!\n");
        return result;
    }
    printf("Wi-Fi Connection Manager initialized.\r\n");

     /* Set the Wi-Fi SSID, password and security type. */
    memset(&wifi_conn_param, 0, sizeof(cy_wcm_connect_params_t));
    memcpy(wifi_conn_param.ap_credentials.SSID, WIFI_SSID, sizeof(WIFI_SSID));
    memcpy(wifi_conn_param.ap_credentials.password, WIFI_PASSWORD, sizeof(WIFI_PASSWORD));
    wifi_conn_param.ap_credentials.security = WIFI_SECURITY_TYPE;

    /* Join the Wi-Fi AP. */
    for(uint32_t conn_retries = 0; conn_retries < MAX_WIFI_CONN_RETRIES; conn_retries++ )
    {
        result = cy_wcm_connect_ap(&wifi_conn_param, &ip_address);

        if(result == CY_RSLT_SUCCESS)
        {
            printf("Successfully connected to Wi-Fi network '%s'.\n",
                                wifi_conn_param.ap_credentials.SSID);
            printf("IP Address Assigned: %d.%d.%d.%d\n", (uint8)ip_address.ip.v4,
                    (uint8)(ip_address.ip.v4 >> 8), (uint8)(ip_address.ip.v4 >> 16),
                    (uint8)(ip_address.ip.v4 >> 24));
            return result;
        }

        printf("Connection to Wi-Fi network failed with error code %d."
               "Retrying in %d ms...\n", (int)result, WIFI_CONN_RETRY_INTERVAL_MSEC);

        vTaskDelay(pdMS_TO_TICKS(WIFI_CONN_RETRY_INTERVAL_MSEC));
    }

    /* Stop retrying after maximum retry attempts. */
    printf("Exceeded maximum Wi-Fi connection attempts\n");

    return result;
}

/*******************************************************************************
 * Function Name: create_tcp_client_socket
 *******************************************************************************
 * Summary:
 *  Function to create a socket and set the socket options
 *  to set call back function for handling incoming messages, call back
 *  function to handle disconnection.
 *
 *******************************************************************************/
cy_rslt_t create_tcp_client_socket()
{
    cy_rslt_t result;

    /* Variables used to set socket options. */
    cy_socket_opt_callback_t tcp_recv_option;
    cy_socket_opt_callback_t tcp_disconnect_option;
//    printf("create_tcp_client_socke\n");
    /* Create a new secure TCP socket. */
    result = cy_socket_create(CY_SOCKET_DOMAIN_AF_INET, CY_SOCKET_TYPE_STREAM,
                              CY_SOCKET_IPPROTO_TCP, &client_handle);

    if (result != CY_RSLT_SUCCESS)
    {
        printf("Failed to create socket!\n");
        return result;
    }

    /* Register the callback function to handle messages received from TCP server. */
    tcp_recv_option.callback = tcp_client_recv_handler;
    tcp_recv_option.arg = NULL;
    result = cy_socket_setsockopt(client_handle, CY_SOCKET_SOL_SOCKET,
                                  CY_SOCKET_SO_RECEIVE_CALLBACK,
                                  &tcp_recv_option, sizeof(cy_socket_opt_callback_t));
    if (result != CY_RSLT_SUCCESS)
    {
        printf("Set socket option: CY_SOCKET_SO_RECEIVE_CALLBACK failed\n");
        return result;
    }

    /* Register the callback function to handle disconnection. */
    tcp_disconnect_option.callback = tcp_disconnection_handler;
    tcp_disconnect_option.arg = NULL;

    result = cy_socket_setsockopt(client_handle, CY_SOCKET_SOL_SOCKET,
                                  CY_SOCKET_SO_DISCONNECT_CALLBACK,
                                  &tcp_disconnect_option, sizeof(cy_socket_opt_callback_t));
    if(result != CY_RSLT_SUCCESS)
    {
        printf("Set socket option: CY_SOCKET_SO_DISCONNECT_CALLBACK failed\n");
    }

    return result;
}

/*******************************************************************************
 * Function Name: connect_to_tcp_server
 *******************************************************************************
 * Summary:
 *  Function to connect to TCP server.
 *
 * Parameters:
 *  cy_socket_sockaddr_t address: Address of TCP server socket
 *
 * Return:
 *  cy_result result: Result of the operation
 *
 *******************************************************************************/
cy_rslt_t connect_to_tcp_server(cy_socket_sockaddr_t address)
{
    cy_rslt_t result = CY_RSLT_MODULE_SECURE_SOCKETS_TIMEOUT;
    cy_rslt_t conn_result;
    //char *cmd;
//    printf("connect_to_tcp_server\n");
    for(uint32_t conn_retries = 0; conn_retries < MAX_TCP_SERVER_CONN_RETRIES; conn_retries++)
    {
        /* Create a TCP socket */
        conn_result = create_tcp_client_socket();
        
        if(conn_result != CY_RSLT_SUCCESS)
        {
            printf("Socket creation failed!\n");
            CY_ASSERT(0);
        }

        conn_result = cy_socket_connect(client_handle, &address, sizeof(cy_socket_sockaddr_t));
        
        if (conn_result == CY_RSLT_SUCCESS)
        {
            printf("===========Connected================================\n");
            printf("Connected to TCP server\n");

//            blynkState = disconnected;
/************************Init Blynk server Hardware Login****************************/
            blynkInit = _hwLogin;
//            result = start_blynk_session();

            if(result == CY_RSLT_SUCCESS)
            {
                printf("Initiated blynk session!\n");
            }
            return conn_result;
        }


        printf("Could not connect to TCP server.\n");
        printf("Trying to reconnect to TCP server... Please check if the server is listening\n");

        /* The resources allocated during the socket creation (cy_socket_create)
         * should be deleted.
         */
        cy_socket_delete(client_handle);
    }

     /* Stop retrying after maximum retry attempts. */
     printf("Exceeded maximum connection attempts to the TCP server\n");

     return result;
}

/*******************************************************************************
 * Function Name: tcp_client_recv_handler
 *******************************************************************************
 * Summary:
 *  Callback function to handle incoming TCP server messages.
 *
 * Parameters:
 *  cy_socket_t socket_handle: Connection handle for the TCP client socket
 *  void *args : Parameter passed on to the function (unused)
 *
 * Return:
 *  cy_result result: Result of the operation
 *
 *******************************************************************************/
cy_rslt_t tcp_client_recv_handler(cy_socket_t socket_handle, void *arg)
{
    /* Variable to store number of bytes send to the TCP server. */
    uint32_t bytes_sent = 0;

    /* Variable to store number of bytes received. */
    uint32_t bytes_received = 0;
    uint32_t bytes_tobe_recv;
    cy_rslt_t result ;
    if((ph.cmd == BLYNK_CMD_HW_LOGIN) || (ph.cmd == BLYNK_CMD_PING)) bytes_tobe_recv =5;
    else bytes_tobe_recv =12;

    //   printf("cp_client_recv_handler\n");
    //xTimerReset(blynk_txtimer, 0);

    printf("========recv handle====================================\n");

    result = cy_socket_recv(socket_handle, ph.rx_Frame, bytes_tobe_recv,CY_SOCKET_FLAGS_NONE, &bytes_received);
    if(result == CY_RSLT_SUCCESS)
    {
    	ph.bytes_recv = bytes_received;
    	printf("rx_Frame received = %s\n", ph.rx_Frame);
       if((ph.rx_Frame[2] == 1) && (ph.rx_Frame[4] == 200))
       {
    	   printf("Hardware Login Authorisation OK!\n");
    	   printf("Started Blynk Session!\n");
    	   blynkState = connected;
		   blynkInit = _tempMin;

    	   /* start blynk tx timer */
    	   //xTimerStart(blynk_txtimer, 0);

        /* start blynk 1ms timer */
        //xTimerStart(blynk_mstimer, 0);
       }
       else if(ph.rx_Frame[0] == 20)
       {
    	   printf("VW message received!\n");
        	decode();
       }
       else
       {
    	   printf("bytes_recv = %d, Unknown rx_Frame Received! = %s\n",ph.bytes_recv,ph.rx_Frame);
       }
    }
    return result;
}

/*******************************************************************************
 * Function Name: tcp_client_sent_handler
 *******************************************************************************
 * Summary:
 *  Callback function to handle outgoing TCP server messages.
 *
 * Parameters:
 *  cy_socket_t socket_handle: Connection handle for the TCP client socket
 *  void *args : Parameter passed on to the function (unused)
 *
 * Return:
 *  cy_result result: Result of the operation
 *
 *******************************************************************************/
cy_rslt_t tcp_client_sent_handler(cy_socket_t socket_handle, void *arg)
{
    /* Variable to store number of bytes send to the TCP server. */
    uint32_t bytes_sent = 0;
    cy_rslt_t result ;

//    printf("tcp_client_sent_handler\n");
    /* Send acknowledgement to the TCP server in receipt of the message received. */
    //xTimerReset(blynk_txtimer, 0);
    printf("===============sent handle======================================\n");
    result = cy_socket_send(socket_handle, ph.tx_Frame, ph.msg_len,CY_SOCKET_FLAGS_NONE, &bytes_sent);
    if(result == CY_RSLT_SUCCESS)
    {
    	ph.bytes_sent = bytes_sent;
    	printf("tx_Frame sent to BlynkServer, msg_len = %d, bytes_sent = %d\n",ph.msg_len,ph.bytes_sent);
    }
    else
    {
        printf("Failed to send command to client. Error: %d\n", (int)result);
        if(result == CY_RSLT_MODULE_SECURE_SOCKETS_CLOSED)
        {
            /* Disconnect the socket. */
            cy_socket_disconnect(client_handle, 0);
        }
    }
    return result;
}

/*******************************************************************************
 * Function Name: tcp_disconnection_handler
 *******************************************************************************
 * Summary:
 *  Callback function to handle TCP socket disconnection event.
 *
 * Parameters:
 *  cy_socket_t socket_handle: Connection handle for the TCP client socket
 *  void *args : Parameter passed on to the function (unused)
 *
 * Return:
 *  cy_result result: Result of the operation
 *
 *******************************************************************************/
cy_rslt_t tcp_disconnection_handler(cy_socket_t socket_handle, void *arg)
{
    cy_rslt_t result;

    blynkState = disconnected;
    blynkInit = _start;
    /* stop blynk tx timer */
    xTimerStop(blynk_txtimer, 0);
    msg_id = 0;
    /* Disconnect the TCP client. */
    result = cy_socket_disconnect(socket_handle, 0);

    /* Free the resources allocated to the socket. */
    cy_socket_delete(socket_handle);

    printf("Disconnected from the TCP server! \n");

    /* Give the semaphore so as to connect to TCP server.  */
    xSemaphoreGive(connect_to_server);

    return result;
}

void msg_frame(uint8_t cmd, char* data)
{

	 ph.cmd = cmd;
	 ph.msg_id = getMsgId();
 	 ph.data_len = strlen(data);
	 ph.msg_len = sprintf(ph.tx_Frame,"%c%c%c%c%c%s",ph.cmd,0,ph.msg_id,0,ph.data_len,data);
}

/****************************************************************************
* Function Name: void ctss_app_msec_timer_cb()
*****************************************************************************
* Summary:
*   Millisecond timer callback.
*   Send GATT notifications if enabled by the GATT Client.
*
* Parameters:
*   timer_handle :  Software timers are reference variable.
*
* Return:
*   None
*
****************************************************************************/

void blynk_mstimer_cb(TimerHandle_t timer_handle)
{
	msec++; /* Increment msec counter*/
}

void blynk_txtimer_cb(TimerHandle_t timer_handle)
{
////    /* send EnvSense & EnvControl data to blynk server */
//	char virtualvalue[15];
//#define data4byte(num,value) sprintf(virtualvalue,"vw%c%d%c%2.2f\n",0,num,0,value);
//#define data2byte(num,value) sprintf(virtualvalue,"vw%c%d%c%02d",0,num,0,value);
//#define data1byte(num,value) sprintf(virtualvalue,"vw%c%d%c%d",0,num,0,value);
//#define header(cmd,id1,id0,len1,len0) sprintf(ph.tx_Frame,"%c%c%c%c%c",cmd,id1,id0,len1,len0)
//	uint8_t datalen,headerlen;
//	cy_rslt_t result;
//	static uint8_t vw_no=0;
//
//
//	if(blynkState == connected)
//	{
//		ph.cmd = BLYNK_CMD_HARDWARE;
//		ph.msg_id = getMsgId();
//		u1._2byte = ph.msg_id;
//
//		switch(vw_no)
//		{
//			case 0:
//					datalen = data4byte(0,vw.tempRead_v0);
//					vw_no = 3;
//				break;
//			case 3:
//					datalen = data4byte(3,vw.humiRead_v3);
//					vw_no = 10;
//				break;
//			case 10:
//					datalen = data2byte(10,vw.servoPosition_v10);
//					vw_no = 11;
//				break;
//			case 11:
//					datalen = data1byte(11,vw.humiState_v11);
////					printf("v11 = %d\n",vw.humiState_v11);
//					vw_no = 12;
//				break;
//			case 12:
//					datalen = data1byte(12,vw.modeInd_v12);
////					printf("v12 = %d\n",vw.modeInd_v12);
//					vw_no = 0;
//				break;
//			default: vw_no = 0;
//				break;
//		}
//			headerlen = header(ph.cmd,u1.ch[1],u1.ch[0],0,datalen);
//			memcpy(&ph.tx_Frame[headerlen],virtualvalue,datalen);
//			ph.msg_len = datalen+headerlen;
////		if(onoff == 0)
////		{
////			datalen = data4byte(0,vw.tempRead_v0);
////			headerlen = header(ph.cmd,u1.ch[1],u1.ch[0],0,datalen);
////			memcpy(&ph.tx_Frame[headerlen],virtualvalue,datalen);
////			ph.msg_len = datalen+headerlen;
////			onoff =1;
////		}
////		else
////		{
////			datalen = data4byte(3,vw.humiRead_v3);
////			headerlen = header(ph.cmd,u1.ch[1],u1.ch[0],0,datalen);
////			memcpy(&ph.tx_Frame[headerlen],virtualvalue,datalen);
////			ph.msg_len = datalen+headerlen;
////			onoff =0;
////		}
//
//		result = tcp_client_sent_handler(client_handle, NULL);
//	    if(result == CY_RSLT_SUCCESS)
//	    {
//	        printf("tx_Frame = %s sent to BlynkServer\n",ph.tx_Frame);
//	    }
//	    else
//	    {
//	        printf("tx_Frame sending failed to BlynkServer\n");
//	    }
//	}
}


void decode(void)
{

// TX                             1  2  3  4  5
//                0  1  2   3  5  6  7  8  9  10 11
//  0 1  2   3 4  5  6  7   8  9  10 11 12 13 14 15
// 14 00 03 00 0B 76 77 00  30 00 33 30 2E 34 30 30   .....vw. 0.30.400
//cmd msgid  len  v  w  \0 var \0 ---- value----  0

// RX
// 14 00 0D 00 08 76 77 00  38 00 31 38 30            .....vw. 8.180
// 14 00 38 00 07 76 77 00  31 00 34 36               ..8..vw. 1.46
// 14 00 12 00 06 76 77 00  36 00 30                  .....vw. 6.0

	char temp[15];
	char rx_dataVar[2];
	char rx_dataVal[3];

	uint16_t i, rx_data_var, rx_data_val;
	for(i=0;i<ph.bytes_recv;i++)
	{
		temp[i] = ph.rx_Frame[i];
	}

	switch(temp[4])
	{
		case 6:
				rx_dataVal[2] = 0;rx_dataVal[1] = 0;rx_dataVal[0] = temp[10];
			break;
		case 7:	rx_dataVal[2] = 0;rx_dataVal[1] = temp[11];rx_dataVal[0] = temp[10];
			break;
		case 8:	rx_dataVal[2] = temp[12];rx_dataVal[1] = temp[11];rx_dataVal[0] = temp[10];
			break;
		default:
			break;
	}
	rx_data_var = temp[8]-0x30;
	rx_data_val = atoi(rx_dataVal);

		switch(rx_data_var)
		{

		case 1: vw.tempMin_v1 = rx_data_val;
				blynk_details._tempMin_v1 = vw.tempMin_v1;
			break;
		case 2: vw.tempMax_v2 = rx_data_val;
				blynk_details._tempMax_v2 = vw.tempMax_v2;
			break;
		case 4: vw.humiMin_v4 = rx_data_val;
				blynk_details._humiMin_v4 = vw.humiMin_v4;
			break;
		case 5: vw.humiMax_v5 = rx_data_val;
				blynk_details._humiMax_v5 = vw.humiMax_v5;
			break;
		case 6: vw.modeSetManual_v6 = rx_data_val;
				vw.modeInd_v12 = vw.modeSetManual_v6;
				blynk_details._prvMode_v12 = vw.modeSetManual_v6;
			break;
		case 7: if(rx_data_val == 11)writeEeprom();
			break;
		case 8: vw.servoPositionManual_v8 = rx_data_val;
				if(vw.modeSetManual_v6 == 11)vw.servoPosition_v10 = vw.servoPositionManual_v8;
				blynk_details._prvPos_v10 = vw.servoPositionManual_v8;
			break;
		case 9: vw.humiStateManual_v9 = rx_data_val;
				if(vw.modeSetManual_v6 == 11)vw.humiState_v11 = vw.humiStateManual_v9;
				blynk_details._prvState_v11 = vw.humiStateManual_v9;
			break;
		default:
			break;
		}
		printf("Data received on VirtualVariable - v%d, Value = %d!\n",rx_data_var,rx_data_val);
}

uint16_t getMsgId(void)
{
	++msg_id;
	if(msg_id >= 65535)msg_id=1;
	return msg_id;
}

cy_rslt_t start_blynk_session(void)
{
	cy_rslt_t result;
//	char auth[] = "ibxXL2bt-x04c4yp4EYRfsgEjwAWxkFE"; // SmartHAServer
//	//char auth[] = "DckE-sKAkBr9iJgpjz0I32iJ0ot1JH_q"; // EnvSense
//
//	msg_frame(BLYNK_CMD_HW_LOGIN, auth);
//	result = tcp_client_sent_handler(client_handle, NULL);

	return result;
}

void writeEeprom(void)
{
	cy_en_em_eeprom_status_t eepromReturnValue;
	/* Write data to EEPROM. */
    eepromReturnValue = Cy_Em_EEPROM_Write(LOGICAL_EEPROM_START,(void *)&blynk_details._tempMin_v1,
                                sizeof(blynk_details), &Em_EEPROM_context);

    if(CY_EM_EEPROM_SUCCESS != eepromReturnValue)
    {
        printf("Failed to write to EMEEPROM: %d\n", eepromReturnValue);
    }
    else
    {
    	printf("Data written to EMEEPROM\n");
    }
}

uint8_t readEeprom(void)
{
    cy_en_em_eeprom_status_t eepromReturnValue;
    eepromReturnValue = Cy_Em_EEPROM_Read(LOGICAL_EEPROM_START, (void *)&blynk_details._tempMin_v1,
                                          sizeof(blynk_details), &Em_EEPROM_context);

    if((CY_EM_EEPROM_SUCCESS == eepromReturnValue) && (0 != blynk_details._tempMin_v1))
    {
        printf("Data present in EMEEPROM\n");
        /* blynk details found in EMEEPROM */
        eepromReturnValue = 0x00;

    }
    else /* blynk details not found in EMEEPROM */
    {
        printf("Data not present in EMEEPROM\n");
        eepromReturnValue = 0x01;
    }
    return eepromReturnValue;
}

/* [] END OF FILE */
