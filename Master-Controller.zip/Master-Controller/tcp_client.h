/******************************************************************************
* File Name:   tcp_client.h
*
* Description: This file contains declaration of task related to TCP client
* operation.
*
*******************************************************************************
* (c) 2019-2020, Cypress Semiconductor Corporation. All rights reserved.
*******************************************************************************
* This software, including source code, documentation and related materials
* ("Software"), is owned by Cypress Semiconductor Corporation or one of its
* subsidiaries ("Cypress") and is protected by and subject to worldwide patent
* protection (United States and foreign), United States copyright laws and
* international treaty provisions. Therefore, you may use this Software only
* as provided in the license agreement accompanying the software package from
* which you obtained this Software ("EULA").
*
* If no EULA applies, Cypress hereby grants you a personal, non-exclusive,
* non-transferable license to copy, modify, and compile the Software source
* code solely for use in connection with Cypress's integrated circuit products.
* Any reproduction, modification, translation, compilation, or representation
* of this Software except as specified above is prohibited without the express
* written permission of Cypress.
*
* Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Cypress
* reserves the right to make changes to the Software without notice. Cypress
* does not assume any liability arising out of the application or use of the
* Software or any product or circuit described in the Software. Cypress does
* not authorize its products for use in any products where a malfunction or
* failure of the Cypress product may reasonably be expected to result in
* significant property damage, injury or death ("High Risk Product"). By
* including Cypress's product in a High Risk Product, the manufacturer of such
* system or application assumes all risk of such use and in doing so agrees to
* indemnify Cypress against all liability.
*******************************************************************************/

#ifndef TCP_CLIENT_H_
#define TCP_CLIENT_H_


//#include "BlynkApiArduino.h"
//#include "BlynkProtocol.h"
//#include "BlynkConfig.h"
//#include "BlynkProtocolDefs.h"
//#include "BlynkApi.h"
//#include "BlynkSimpleWifi.h"
//#include "BlynkSimpleStream.h"
//#include "BlynkSimpleWifi.h"
#include "Blynk.h"
#include <stdlib.h>
#include "timers.h"
/* Cypress secure socket header file. */
#include "cy_secure_sockets.h"

#include "cy_em_eeprom.h"
/*******************************************************************************
* Macros
********************************************************************************/
/* Wi-Fi Credentials: Modify WIFI_SSID, WIFI_PASSWORD and WIFI_SECURITY_TYPE
 * to match your Wi-Fi network credentials.
 * Note: Maximum length of the Wi-Fi SSID and password is set to
 * CY_WCM_MAX_SSID_LEN and CY_WCM_MAX_PASSPHRASE_LEN as defined in cy_wcm.h file.
 */

#define WIFI_SSID                         "wifi_ssid"
#define WIFI_PASSWORD                     "wifi_password"

/* Security type of the Wi-Fi access point. See 'cy_wcm_security_t' structure
 * in "cy_wcm.h" for more details.
 */
#define WIFI_SECURITY_TYPE                 CY_WCM_SECURITY_WPA2_AES_PSK

/* Maximum number of connection retries to the Wi-Fi network. */
#define MAX_WIFI_CONN_RETRIES             (10u)

/* Wi-Fi re-connection time interval in milliseconds */
#define WIFI_CONN_RETRY_INTERVAL_MSEC     (1000)

#define MAKE_IPV4_ADDRESS(a, b, c, d)     ((((uint32_t) d) << 24) | \
                                          (((uint32_t) c) << 16) | \
                                          (((uint32_t) b) << 8) |\
                                          ((uint32_t) a))

/* Change the server IP address to match the TCP server address (IP address
 * of the PC).
 */
#define TCP_SERVER_IP_ADDRESS             MAKE_IPV4_ADDRESS(192, 168, 43, 44)//MAKE_IPV4_ADDRESS(192, 168, 43, 44)

#define TCP_SERVER_PORT                   80//9443//50007

#define val(x,y,z)  x##y##z
//union value
//{
//	uint
//};
 struct VirtualWrite
 {
	 /* data received from EnvSense*/
	float tempRead_v0;
	float humiRead_v3;

	/* manual data received from App*/
	uint8_t servoPositionManual_v8;
	uint8_t humiStateManual_v9;
	uint8_t modeSetManual_v6, tempMin_v1, tempMax_v2, humiMin_v4, humiMax_v5;

	/* data sent to EnvControl*/
	uint8_t servoPosition_v10;
	uint8_t humiState_v11;
	uint8_t modeInd_v12;
 };
 struct ProtocolHeader
 {
	    uint8_t  cmd; 		//blynk command
	    uint16_t msg_id; 	//blynk msg id
	    uint16_t data_len;	//blynk msg data length
	    uint16_t msg_len;	//blynk msg total length;
	    uint8_t bytes_sent; //bytes sent in a msg;
	    uint8_t bytes_recv; //bytes received in a msg
	    char rx_Frame[50];	//blynk rx msg buffer
	    char tx_Frame[50];	//blynk tx msg buffer
 };

 union u
 {
     uint16_t _2byte;
     float _4byte;
     char ch[4];
 }u1;
 enum blynkState{ disconnected =0, connected};
 enum blynkInit{_start=0,_hwLogin,_tempMin,_tempMax,_humiMin,_humiMax,_modeSet,_setHeater,_setHumiState,completed};
/*************************************************************************************************/
 /* Logical Start of Emulated EEPROM in bytes. */
 #define LOGICAL_EEPROM_START    (0u)

 /* EEPROM Configuration details. */
 #define SIMPLE_MODE             (0u)
 #define EEPROM_SIZE             (512u)
 #define BLOCKING_WRITE          (1u)
 #define REDUNDANT_COPY          (1u)
 #define WEAR_LEVELLING_FACTOR   (2u)

 /* Set the macro FLASH_REGION_TO_USE to either USER_FLASH or
  * EMULATED_EEPROM_FLASH to specify the region of the flash used for
  * emulated EEPROM.
  */
 #define USER_FLASH              (0u)
 #define EMULATED_EEPROM_FLASH   (1u)
 #define FLASH_REGION_TO_USE     EMULATED_EEPROM_FLASH
 /******************************************************************************
  *                                Structures
  ******************************************************************************/
 /* Structure to store WiFi details that goes into EEPROM */
 typedef __PACKED_STRUCT
 {
//     uint8_t wifi_ssid[CY_WCM_MAX_SSID_LEN];
//     uint8_t ssid_len;
//     uint8_t wifi_password[CY_WCM_MAX_PASSPHRASE_LEN];
//     uint8_t password_len;
/* manual data received from App*/
	 uint8_t _tempMin_v1;
	 uint8_t _tempMax_v2;
	 uint8_t _humiMin_v4;
	 uint8_t _humiMax_v5;
     uint8_t _prvPos_v10;
     uint8_t _prvState_v11;
     uint8_t _prvMode_v12;
 }blynk_details_t;//wifi_details_t;

 /******************************************************************************
  *                              Extern Variables
  ******************************************************************************/
 extern cy_stc_eeprom_context_t Em_EEPROM_context;
 extern cy_stc_eeprom_config_t Em_EEPROM_config;
 /*******************************************************************************
* Function Prototype
********************************************************************************/
void tcp_client_task(void *arg);
uint16_t getMsgId(void);
cy_rslt_t tcp_client_sent_handler(cy_socket_t socket_handle, void *arg);
void writeEeprom(void);
uint8_t readEeprom(void);
#endif /* TCP_CLIENT_H_ */
