/******************************************************************************
* File Name: main.c
*
* Description:This is the source code for the AnyCloud: BLE CTS Server Example
*             for ModusToolbox.
*
* Related Document: See README.md
*
*******************************************************************************/

/*******************************************************************************
* (c) 2020, Cypress Semiconductor Corporation. All rights reserved.
*******************************************************************************
* This software, including source code, documentation and related materials
* ("Software"), is owned by Cypress Semiconductor Corporation or one of its
* subsidiaries ("Cypress") and is protected by and subject to worldwide patent
* protection (United States and foreign), United States copyright laws and
* international treaty provisions. Therefore, you may use this Software only
* as provided in the license agreement accompanying the software package from
* which you obtained this Software ("EULA").
*
* If no EULA applies, Cypress hereby grants you a personal, non-exclusive,
* non-transferable license to copy, modify, and compile the Software source
* code solely for use in connection with Cypress's integrated circuit products.
* Any reproduction, modification, translation, compilation, or representation
* of this Software except as specified above is prohibited without the express
* written permission of Cypress.
*
* Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Cypress
* reserves the right to make changes to the Software without notice. Cypress
* does not assume any liability arising out of the application or use of the
* Software or any product or circuit described in the Software. Cypress does
* not authorize its products for use in any products where a malfunction or
* failure of the Cypress product may reasonably be expected to result in
* significant property damage, injury or death ("High Risk Product"). By
* including Cypress's product in a High Risk Product, the manufacturer of such
* system or application assumes all risk of such use and in doing so agrees to
* indemnify Cypress against all liability.
*******************************************************************************/

/*******************************************************************************
*        Header Files
*******************************************************************************/
/* Header file includes */
#include "cybsp.h"
#include "cy_retarget_io.h"
#include "cyabs_rtos.h"
#include "timers.h"
#include "cyhal.h"
#include "cybt_platform_trace.h"

/* FreeRTOS header file */
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>

/* Standard C header file */
#include "stdlib.h"
#include "stdio.h"
#include <string.h>

/* BT connection manager header files */
#include "wiced_bt_dev.h"
#include "app_bt_utils.h"
#include "app_bt_cfg.h"
#include "wiced_bt_stack.h"
#include "wiced_memory.h"
//#include "GeneratedSource/cycfg_bt_settings.h"
//#include "GeneratedSource/cycfg_gap.h"
#include "GeneratedSource/cycfg_gatt_db.h"

/* TCP client task header file. */
#include "tcp_client.h"
/*******************************************************************************
* Macros
********************************************************************************/
/* RTOS related macros. */
#define TCP_CLIENT_TASK_STACK_SIZE        (10 * 1024)
#define TCP_CLIENT_TASK_PRIORITY          (1)
/*******************************************************************************
* Global Variables
********************************************************************************/
/* This enables RTOS aware debugging. */
volatile int uxTopUsedPriority;
/******************************************************************************
 *                           Constants and Enumerations
 ******************************************************************************/
//#define STRING_BUFFER_SIZE                  (80)
//#define DAYS_PER_WEEK                       (7u)

/* LED pin assignment for advertising event */
#define ADV_LED_GPIO                    CYBSP_USER_LED1
/* PWM frequency of LED's in Hz when blinking */
#define ADV_LED_PWM_FREQUENCY           (1)
/* ENVSENSE Service UUID - used for service discovery */
#define ENVSENSE_SERVICE_UUID                (0x1856)
/* ENVSENSE Service UUID length */
#define ENVSENSE_SERVICE_UUID_LEN            (2)
/* ENVSENSE characteristic descriptor length - used to subscribe for notification */
#define CCCD_LENGTH                     ENVSENSE_SERVICE_UUID_LEN
/* Value used to derive handle of CCCD of current time characteristic */
#define GATT_CCCD_HANDLE                (3)

/* PWM Duty Cycle of LED's for different states */
enum
{
    LED_ON_DUTY_CYCLE = 0,
    LED_BLINKING_DUTY_CYCLE= 50,
    LED_OFF_DUTY_CYCLE = 100
} led_duty_cycles;

/* This enumeration combines the advertising, connection states from two different
 * callbacks to maintain the status in a single state variable */
typedef enum
{
    APP_BT_ADV_OFF_CONN_OFF,
    APP_BT_ADV_ON_CONN_OFF,
    APP_BT_ADV_OFF_CONN_ON
} app_bt_adv_conn_mode_t;

/*******************************************************************************
*        Variable Definitions
*******************************************************************************/
static uint16_t                  bt_connection_id_envsense = 0; // evnsense server connection id
static TimerHandle_t             app_msec_timer;
static cyhal_pwm_t               adv_led_pwm;
static uint16_t                  bt_connection_id_envcontrol = 0; // evncontrol client connection id
static app_bt_adv_conn_mode_t    app_bt_adv_conn_state = APP_BT_ADV_OFF_CONN_OFF;
static uint16_t                  envsense_service_handle = 0;
static bool                      envsense_service_found = false;

/* TCP client socket handle */
extern cy_socket_t client_handle;
extern uint8_t blynkState;
extern uint8_t blynkInit;
char virtualvalue[15];
#define data4byte(num,value) sprintf(virtualvalue,"vw%c%d%c%2.2f\n",0,num,0,value);
#define data2byte(num,value) sprintf(virtualvalue,"vw%c%d%c%02d\n",0,num,0,value);
#define data1byte(num,value) sprintf(virtualvalue,"vw%c%d%c%d\n",0,num,0,value);
#define header(cmd,id1,id0,len1,len0) sprintf(ph.tx_Frame,"%c%c%c%c%c",cmd,id1,id0,len1,len0)
#define hwLogin(cmd,id1,id0,len1,len0,key) sprintf(ph.tx_Frame,"%c%c%c%c%c%s",cmd,id1,id0,len1,len0,key);
char auth[] = "6KpFybBygeL6LjqTcts7w1ehlVBHqplA";//"ibxXL2bt-x04c4yp4EYRfsgEjwAWxkFE"; // SmartHAServer

extern blynk_details_t blynk_details;

float temperature = 0; 				/* v0 */
float humidity = 0; 				/* v3 */
uint8_t servoPosition = 11;		    /* v10 */
uint8_t humiState = 0; 				/* v11 */
uint8_t modeInd = 0; 				/* v12 */
uint8_t prvKnobPos=0;
uint8_t curKnobPos=0;

uint8_t EnvSense_SID[2] = {0x18,0x56};
uint8_t EnvControl_SID[2] = {0x18,0x55};
uint8_t EnvSense[6] = {0x24, 0xa1, 0x60, 0x47, 0x48, 0x72};
uint8_t EnvControl[6] = {0x50, 0x02, 0x91, 0x8d, 0xa6, 0x9a};
volatile uint32_t msec = 0;
static uint32_t secCnt = 0;
struct VirtualWrite vw;
struct ProtocolHeader ph;
/*******************************************************************************
*        Function Prototypes Bluetooth
*******************************************************************************/;
static void                   ble_app_init              (void);
static void                   scan_result_cback         (wiced_bt_ble_scan_results_t *p_scan_result, uint8_t *p_adv_data );
static void                   send_notification         (void);
static void                   app_msec_timer_cb         (TimerHandle_t timer_handle);
/*********************************Client*************************************************/
static void                   adv_led_update                 (void);
static void                   ble_app_set_advertisement_data (void);
static wiced_bt_gatt_status_t enable_gatt_notification       (void);
static void                   print_notification_data        (wiced_bt_gatt_data_t notif_data);
void check_condition(void);
void init_env_param(void);
/***************************************************************************************/
gatt_db_lookup_table_t*       get_attribute             (uint16_t handle);

/* GATT Event Callback Functions */
static wiced_bt_gatt_status_t ble_app_write_handler          (wiced_bt_gatt_write_t *p_write_req, uint16_t conn_id);
static wiced_bt_gatt_status_t ble_app_read_handler           (wiced_bt_gatt_read_t *p_read_req, uint16_t conn_id);
static wiced_bt_gatt_status_t ble_app_connect_callback       (wiced_bt_gatt_connection_status_t *p_conn_status);
static wiced_bt_gatt_status_t ble_app_server_callback        (uint16_t conn_id, wiced_bt_gatt_request_type_t type, wiced_bt_gatt_request_data_t *p_data);
static wiced_bt_gatt_status_t ble_app_gatt_event_handler     (wiced_bt_gatt_evt_t event, wiced_bt_gatt_event_data_t *p_event_data);

/* Callback function for Bluetooth stack management type events */
static wiced_bt_dev_status_t  app_bt_management_callback     (wiced_bt_management_evt_t event, wiced_bt_management_evt_data_t *p_event_data);
/******************************************************************************
 *                          Function Definitions
 ******************************************************************************/
/*
 *  Entry point to the application. Set device configuration and start BT
 *  stack initialization.  The actual application initialization will happen
 *  when stack reports that BT device is ready.
 */
int main()
{
    cy_rslt_t rslt;
    wiced_result_t result;
    /* Return status for EEPROM. */
    cy_en_em_eeprom_status_t eepromReturnValue;

    /* This enables RTOS aware debugging in OpenOCD. */
    uxTopUsedPriority = configMAX_PRIORITIES - 1;

    /* Initialize the board support package */
    rslt = cybsp_init() ;
    if (CY_RSLT_SUCCESS != rslt)
    {
        CY_ASSERT(0);
    }

    /* To avoid compiler warnings. */
    (void) result;

    /* Enable global interrupts */
    __enable_irq();


    if(CY_EM_EEPROM_SUCCESS != eepromReturnValue)
    {
        printf("Error initializing EMEEPROM\n");
        CY_ASSERT(0);
    }

    /* Initialize retarget-io to use the debug UART port */
    cy_retarget_io_init(CYBSP_DEBUG_UART_TX, CYBSP_DEBUG_UART_RX,
                        CY_RETARGET_IO_BAUDRATE);

    /* Initialize the EMEEPROM. */
    eepromReturnValue = Cy_Em_EEPROM_Init(&Em_EEPROM_config, &Em_EEPROM_context);

    /* Initialize default Env variables */
    init_env_param();

    cybt_platform_config_init(&bt_platform_cfg_settings);
    printf("****** BLE Server and then TCP Client Start ******\n\n");

    /* Register call back and configuration with stack */
    result = wiced_bt_stack_init (app_bt_management_callback, &wiced_bt_cfg_settings);

    /* Check if stack initialization was successful */
    if( WICED_BT_SUCCESS == result)
    {
        printf("Bluetooth Stack Initialization Successful\n");
    }
    else
    {
        printf("Bluetooth Stack Initialization failed!!\n");
        CY_ASSERT(0);
    }

    /* Create the tasks. */
    xTaskCreate(tcp_client_task, "Network task", TCP_CLIENT_TASK_STACK_SIZE, NULL,
                TCP_CLIENT_TASK_PRIORITY, NULL);

    /* Start the FreeRTOS scheduler */
    vTaskStartScheduler() ;

    /* Should never get here */
    CY_ASSERT(0) ;
}

/**************************************************************************************************
* Function Name: app_bt_management_callback()
***************************************************************************************************
* Summary:
*   This is a Bluetooth stack event handler function to receive management events from
*   the BLE stack and process as per the application.
*
* Parameters:
*   wiced_bt_management_evt_t event             : BLE event code of one byte length
*   wiced_bt_management_evt_data_t *p_event_data: Pointer to BLE management event structures
*
* Return:
*  wiced_result_t: Error code from WICED_RESULT_LIST or BT_RESULT_LIST
*
*************************************************************************************************/
wiced_result_t app_bt_management_callback(wiced_bt_management_evt_t event, wiced_bt_management_evt_data_t *p_event_data)
{
    wiced_result_t result = WICED_BT_SUCCESS;
    wiced_bt_device_address_t bda = { 0 };
    wiced_bt_ble_advert_mode_t *p_adv_mode = NULL;
    //printf("app_bt_management_callback function\r\n");
    switch (event)
    {
        case BTM_ENABLED_EVT:
            /* Bluetooth Controller and Host Stack Enabled */

            if (WICED_BT_SUCCESS == p_event_data->enabled.status)
            {
                /* Bluetooth is enabled */
                wiced_bt_dev_read_local_addr(bda);
                printf("Local Bluetooth Address: ");
                print_bd_address(bda);

                /* Perform application-specific initialization */
                ble_app_init();
            }

            break;

        case BTM_BLE_SCAN_STATE_CHANGED_EVT:

            if(p_event_data->ble_scan_state_changed == BTM_BLE_SCAN_TYPE_HIGH_DUTY)
            {
                printf("Scan State Change: BTM_BLE_SCAN_TYPE_HIGH_DUTY\n");
            }
            else if(p_event_data->ble_scan_state_changed == BTM_BLE_SCAN_TYPE_LOW_DUTY)
            {
                printf("Scan State Change: BTM_BLE_SCAN_TYPE_LOW_DUTY\n");
            }
            else if(p_event_data->ble_scan_state_changed == BTM_BLE_SCAN_TYPE_NONE)
            {
                printf("Scan stopped\n");
            }
            else
            {
                printf("Invalid scan state\n");
            }
            break;

        case BTM_BLE_ADVERT_STATE_CHANGED_EVT:

            /* Advertisement State Changed */
            p_adv_mode = &p_event_data->ble_advert_state_changed;
            printf("Advertisement State Change: %s\n", get_bt_advert_mode_name(*p_adv_mode));

            if (BTM_BLE_ADVERT_OFF == *p_adv_mode)
            {
                /* Advertisement Stopped */
                printf("Advertisement stopped\n");

                /* Check connection status after advertisement stops */
                if(bt_connection_id_envsense == 0)
                {
                    app_bt_adv_conn_state = APP_BT_ADV_OFF_CONN_OFF;
                }
                else
                {
                    app_bt_adv_conn_state = APP_BT_ADV_OFF_CONN_ON;
                }
            }
            else
            {
                /* Advertisement Started */
                printf("Advertisement started\n");
                app_bt_adv_conn_state = APP_BT_ADV_ON_CONN_OFF;
            }

            /* Update Advertisement LED to reflect the updated state */
            adv_led_update();
            break;

        case BTM_PAIRED_DEVICE_LINK_KEYS_REQUEST_EVT:
			break;

        default:
            printf("Unhandled Bluetooth Management Event: 0x%x %s\n", event, get_bt_event_name(event));
            break;
    }

    return result;
}

/**************************************************************************************************
* Function Name: ble_app_init()
***************************************************************************************************
* Summary:
*   This function handles application level initialization tasks and is called from the BT
*   management callback once the BLE stack enabled event (BTM_ENABLED_EVT) is triggered
*   This function is executed in the BTM_ENABLED_EVT management callback.
*
* Parameters:
*   None
*
* Return:
*  None
*
*************************************************************************************************/
static void ble_app_init(void)
{
    cy_rslt_t rslt;
    wiced_result_t result;
    wiced_bt_gatt_status_t status;

    //printf("ble_app_init function\r\n");

    /* Initialize the timer for notification with 2000ms timeout period*/
    app_msec_timer = xTimerCreate("app_msec_timer", pdMS_TO_TICKS(5000), pdTRUE,
                                        NULL, app_msec_timer_cb);

    /* Timer init failed. Stop program execution */
    if (NULL == app_msec_timer)
    {
        printf("[Error] : Timer Initialization failed 0x%lX\r\n", rslt);
        CY_ASSERT(0);
    }

    rslt = cyhal_pwm_init(&adv_led_pwm, ADV_LED_GPIO , NULL);

   /* Disable pairing for this application */
    wiced_bt_set_pairable_mode(WICED_FALSE, 0);

    ble_app_set_advertisement_data();

    /* Register with BT stack to receive GATT callback */
    status=wiced_bt_gatt_register(ble_app_gatt_event_handler);
    printf("GATT event Handler registration status: %s \n",get_bt_gatt_status_name(status));

    /* Initialize GATT Database */
    status = wiced_bt_gatt_db_init(gatt_database, gatt_database_len, NULL);
    printf("GATT database initialization status: %s \n",get_bt_gatt_status_name(status));

    result = wiced_bt_ble_scan(BTM_BLE_SCAN_TYPE_HIGH_DUTY, WICED_TRUE, scan_result_cback);
    if ((WICED_BT_PENDING == result) || (WICED_BT_BUSY == result))
    {
        printf("\r\nScanning.....\n");
    }
    else
    {
        printf("\rError: Starting scan failed. Error code: %d\n", result);
        return;
    }
}

/***************************************************************************************
* Function Name: void ctss_scan_result_cback()
****************************************************************************************
* Summary:
*   This function is registered as a callback to handle the scan results.
*   When the desired device is found, it will try to establish connection with
*   that device.
*
* Parameters:
*   wiced_bt_ble_scan_results_t *p_scan_result: Details of the new device found.
*   uint8_t                     *p_adv_data      : Advertisement data.
*
* Return:
*   None
*
****************************************************************************************/
void scan_result_cback(wiced_bt_ble_scan_results_t *p_scan_result, uint8_t *p_adv_data )
{
    wiced_result_t         result = WICED_BT_SUCCESS;
    //printf("ctss_scan_result_cback function\r\n");

    if (p_scan_result)
    {
        if ((memcmp(p_scan_result->remote_bd_addr, (uint8_t *)EnvSense, 6) == 0))
        {
            printf("\nFound the peer device! BD Addr: ");
            print_bd_address(p_scan_result->remote_bd_addr);

            /* Device found. Stop scan. */
            if((result = wiced_bt_ble_scan(BTM_BLE_SCAN_TYPE_NONE, WICED_TRUE,
                                           scan_result_cback))!= WICED_BT_SUCCESS)
            {
                printf("\r\nscan off status %d\n", result);
            }
            else
            {
                printf("Scan completed\n\n");
            }

            printf("Initiating connection\n");
            /* Initiate the connection */
            if(wiced_bt_gatt_le_connect(p_scan_result->remote_bd_addr,
                                        p_scan_result->ble_addr_type,
                                        BLE_CONN_MODE_HIGH_DUTY,
                                        WICED_TRUE)!= WICED_TRUE)
            {
                printf("\rwiced_bt_gatt_connect failed\n");
            }
        }
        else
        {
            printf("BD Addr: ");
            print_bd_address(p_scan_result->remote_bd_addr);
            return;    //Skip - This is not the device we are looking for.
        }
    }
}

/**************************************************************************************************
* Function Name: ble_app_gatt_event_handler()
***************************************************************************************************
* Summary:
*   This function handles GATT events from the BT stack.
*
* Parameters:
*   wiced_bt_gatt_evt_t event                   : BLE GATT event code of one byte length
*   wiced_bt_gatt_event_data_t *p_event_data    : Pointer to BLE GATT event structures
*
* Return:
*  wiced_bt_gatt_status_t: See possible status codes in wiced_bt_gatt_status_e in wiced_bt_gatt.h
*
**************************************************************************************************/
static wiced_bt_gatt_status_t ble_app_gatt_event_handler(wiced_bt_gatt_evt_t event, wiced_bt_gatt_event_data_t *p_event_data)
{
    wiced_bt_gatt_status_t status = WICED_BT_GATT_ERROR;
    wiced_bt_gatt_attribute_request_t *p_attr_req = NULL;
    wiced_result_t result = WICED_BT_SUCCESS;
    //printf("ble_app_gatt_event_handler function\r\n");
    /* Call the appropriate callback function based on the GATT event type, and pass the relevant event
     * parameters to the callback function */
    switch ( event )
    {
        case GATT_CONNECTION_STATUS_EVT:
            status = ble_app_connect_callback( &p_event_data->connection_status );
            break;

        case GATT_ATTRIBUTE_REQUEST_EVT:
            p_attr_req = &p_event_data->attribute_request;
            status = ble_app_server_callback( p_attr_req->conn_id, p_attr_req->request_type, &p_attr_req->data );
            break;

        case GATT_DISCOVERY_RESULT_EVT:
            /* Check if CTS service UUID is present*/
            if (ENVSENSE_SERVICE_UUID == p_event_data->discovery_result.discovery_data.group_value.service_type.uu.uuid16)
            {
                /* Copy the CTS service UUID*/
                envsense_service_handle = p_event_data->discovery_result.discovery_data.group_value.s_handle;
                envsense_service_found = true;
            }
            break;

        case GATT_DISCOVERY_CPLT_EVT:
            if(envsense_service_found)
            {
                printf("ENVSENSE service found\n");
                if(WICED_BT_GATT_SUCCESS != enable_gatt_notification())
                {
                    printf("Enable notification failed!\n");
                }
/************************Start Adv after EnvSense connected****************************************/
                /* Start Undirected LE Advertisements on device startup.
                 * The corresponding parameters are contained in 'app_bt_cfg.c' */
                result = wiced_bt_start_advertisements(BTM_BLE_ADVERT_UNDIRECTED_HIGH, 0, NULL);
                if(WICED_BT_SUCCESS != result)
                {
                	printf("Advertisement cannot start because of error: %d \n",result);
                    CY_ASSERT(0);
                }
/*************************************************************************************************/
            }
            else
            {
                printf("ENVSENSE service not found\n");
            }
            break;

        case GATT_OPERATION_CPLT_EVT:
            switch (p_event_data->operation_complete.op)
            {
                case GATTC_OPTYPE_WRITE:
                    /* Check if GATT operation of enable/disable notification is success. */
                    if ((p_event_data->operation_complete.response_data.handle == (envsense_service_handle + GATT_CCCD_HANDLE))
                        && (WICED_BT_GATT_SUCCESS == p_event_data->operation_complete.status))
                    {
                        printf("Notifications enabled\n");
                    }
                    else
                    {
                        printf("CCCD update failed. Error: %d\n", p_event_data->operation_complete.status);
                    }
                    break;

                case GATTC_OPTYPE_NOTIFICATION:
                    /* Function call to print the time and date notifcation */
                    print_notification_data(p_event_data->operation_complete.response_data.att_value);
                    break;
            }
            break;

        default:
            status = WICED_BT_GATT_SUCCESS;
            break;
    }

    return status;
}

/**************************************************************************************************
* Function Name: ble_app_get_value()
***************************************************************************************************
* Summary:
*   This function handles reading of the attribute value from the GATT database and passing the
*   data to the BT stack. The value read from the GATT database is stored in a buffer whose
*   starting address is passed as one of the function parameters
*
* Parameters:
*   uint16_t attr_handle                    : Attribute handle for read operation
*   uint16_t conn_id                        : Connection ID
*   uint8_t *p_val                          : Pointer to the buffer to store read data
*   uint16_t max_len                        : Maximum buffer length available to store the read data
*   uint16_t *p_len                         : Actual length of data copied to the buffer
*
* Return:
*   wiced_bt_gatt_status_t: See possible status codes in wiced_bt_gatt_status_e in wiced_bt_gatt.h
*
**************************************************************************************************/
static wiced_bt_gatt_status_t ble_app_get_value(uint16_t attr_handle, uint16_t conn_id, uint8_t *p_val, uint16_t max_len, uint16_t *p_len)
{
    wiced_bool_t isHandleInTable = WICED_FALSE;
    wiced_bt_gatt_status_t res = WICED_BT_GATT_INVALID_HANDLE;

    //printf("ble_app_get_value function\r\n");
    /* Check for a matching handle entry */
    for (int i = 0; i < app_gatt_db_ext_attr_tbl_size; i++)
    {
        if (app_gatt_db_ext_attr_tbl[i].handle == attr_handle)
        {
            /* Detected a matching handle in external lookup table */
            isHandleInTable = WICED_TRUE;

            /* Check if the buffer has space to store the data */
            if (app_gatt_db_ext_attr_tbl[i].cur_len <= max_len)
            {
                /* Update the GATT DB with current RTC data */
                if(attr_handle == HDLC_ENVCONTROL_CONTROLPOSITION_VALUE)
                {
                	app_envcontrol_controlposition[0]= (uint8_t) (servoPosition & 0xFF);
                	app_envcontrol_controlposition[1]= (uint8_t) ((servoPosition) >> 8);
                	app_envcontrol_controlposition[2]= humiState;
                	app_envcontrol_controlposition[3]= modeInd;
                }

                /* Value fits within the supplied buffer; copy over the value */
                *p_len = app_gatt_db_ext_attr_tbl[i].cur_len;
                memcpy(p_val, app_gatt_db_ext_attr_tbl[i].p_data, app_gatt_db_ext_attr_tbl[i].cur_len);
                res = WICED_BT_GATT_SUCCESS;
            }
            else
            {
                /* Value to read will not fit within the buffer */
                res = WICED_BT_GATT_INVALID_ATTR_LEN;
            }
            break;
        }
    }

    if (!isHandleInTable)
    {
        /* Add code to read value for handles not contained within generated lookup table.
         * This is a custom logic that depends on the application, and is not used in the
         * current application. If the value for the current handle is successfully read in the
         * below code snippet, then set the result using:
         * res = WICED_BT_GATT_SUCCESS; */
        switch ( attr_handle )
        {
            default:
                /* The read operation was not performed for the indicated handle */
                printf("Read Request to Invalid Handle: 0x%x\n", attr_handle);
                res = WICED_BT_GATT_READ_NOT_PERMIT;
                break;
        }
    }

    return res;
}

/**************************************************************************************************
* Function Name: ble_app_set_value()
***************************************************************************************************
* Summary:
*   This function handles writing to the attribute handle in the GATT database using the
*   data passed from the BT stack. The value to write is stored in a buffer
*   whose starting address is passed as one of the function parameters
*
* Parameters:
*   uint16_t attr_handle                    : Attribute handle for write operation
*   uint16_t conn_id                        : Connection ID
*   uint8_t *p_val                          : Pointer to the buffer that stores the data to be written
*   uint16_t len                            : Length of data to be written
*
* Return:
*   wiced_bt_gatt_status_t: See possible status codes in wiced_bt_gatt_status_e in wiced_bt_gatt.h
*
**************************************************************************************************/
static wiced_bt_gatt_status_t ble_app_set_value(uint16_t attr_handle, uint16_t conn_id, uint8_t *p_val, uint16_t len)
{
    int i = 0;
    wiced_bool_t isHandleInTable = WICED_FALSE;
    wiced_bool_t validLen = WICED_FALSE;
    wiced_bt_gatt_status_t res = WICED_BT_GATT_INVALID_HANDLE;
    gatt_db_lookup_table_t *puAttribute;

    //printf("ble_app_set_value function\r\n");
    /* Check for a matching handle entry */
    for (i = 0; i < app_gatt_db_ext_attr_tbl_size; i++)
    {
        if (app_gatt_db_ext_attr_tbl[i].handle == attr_handle)
        {
            /* Detected a matching handle in external lookup table */
            isHandleInTable = WICED_TRUE;

            /* Check if the buffer has space to store the data */
            validLen = (app_gatt_db_ext_attr_tbl[i].max_len >= len);

            if (validLen)
            {
                /* Value fits within the supplied buffer; copy over the value */
                app_gatt_db_ext_attr_tbl[i].cur_len = len;
                memcpy(app_gatt_db_ext_attr_tbl[i].p_data, p_val, len);
                res = WICED_BT_GATT_SUCCESS;

                /* Add code for any action required when this attribute is written.
                 * In this case, we update the IAS led based on the IAS alert
                 * level characteristic value */

                switch ( attr_handle )
                {
                    case HDLD_ENVCONTROL_CONTROLPOSITION_CLIENT_CHAR_CONFIG:
                        if (len!= app_envcontrol_controlposition_client_char_config_len)
                        {
                            printf("Invalid attribute length\n");
                            return WICED_BT_GATT_INVALID_ATTR_LEN;
                        }

                        app_envcontrol_controlposition_client_char_config[0] = p_val[0];
                        app_envcontrol_controlposition_client_char_config[1] = p_val[1];

                        /* Update GATT DB */
                        if ((puAttribute = get_attribute(attr_handle)) != NULL)
                        {
                        	memcpy(puAttribute->p_data, (uint8_t *)app_envcontrol_controlposition_client_char_config,
                                                                        puAttribute->max_len);
                        }

                        if(app_envcontrol_controlposition_client_char_config[0])
                        {
                            printf("\r\nNotifications enabled\n");
                            if(pdPASS != xTimerStart(app_msec_timer, 0))
                            {
                                printf("\rMillisecond timer start failed\n");
                            }
                        }
                        else
                        {
                            printf("\rNotifications disabled\n");
                            xTimerStop(app_msec_timer, 0);
                        }
                        break;

                }           
            }
            else
            {
                /* Value to write does not meet size constraints */
                res = WICED_BT_GATT_INVALID_ATTR_LEN;
            }
            break;
        }
    }

    if (!isHandleInTable)
    {
        /* TODO: Add code to read value for handles not contained within generated lookup table.
         * This is a custom logic that depends on the application, and is not used in the
         * current application. If the value for the current handle is successfully written in the
         * below code snippet, then set the result using:
         * res = WICED_BT_GATT_SUCCESS; */
        switch ( attr_handle )
        {
            default:
                /* The write operation was not performed for the indicated handle */
                printf("Write Request to Invalid Handle: 0x%x\n", attr_handle);
                res = WICED_BT_GATT_WRITE_NOT_PERMIT;
                break;
        }
    }

    return res;
}

/**************************************************************************************************
* Function Name: ble_app_write_handler()
***************************************************************************************************
* Summary:
*   This function handles Write Requests received from the client device
*
* Parameters:
*   wiced_bt_gatt_write_t *p_write_req          : Pointer that contains details of Write Request
*                                                 including the attribute handle
*   uint16_t conn_id                            : Connection ID
*
* Return:
*  wiced_bt_gatt_status_t: See possible status codes in wiced_bt_gatt_status_e in wiced_bt_gatt.h
*
**************************************************************************************************/
static wiced_bt_gatt_status_t ble_app_write_handler(wiced_bt_gatt_write_t *p_write_req, uint16_t conn_id)
{
    wiced_bt_gatt_status_t status = WICED_BT_GATT_INVALID_HANDLE;
    //printf("ble_app_write_handler function\r\n");
    /* Attempt to perform the Write Request */
    status = ble_app_set_value(p_write_req->handle, conn_id, p_write_req->p_val, p_write_req->val_len);
    printf("Value = %d written by conn_id = %d\r\n",*p_write_req->p_val, conn_id);
    return status;
}

/**************************************************************************************************
* Function Name: ble_app_read_handler()
***************************************************************************************************
* Summary:
*   This function handles Read Requests received from the client device
*
* Parameters:
*   wiced_bt_gatt_write_t *p_read_req           : Pointer that contains details of Read Request
*                                                 including the attribute handle
*   uint16_t conn_id                            : Connection ID
*
* Return:
*  wiced_bt_gatt_status_t: See possible status codes in wiced_bt_gatt_status_e in wiced_bt_gatt.h
*
**************************************************************************************************/
static wiced_bt_gatt_status_t ble_app_read_handler( wiced_bt_gatt_read_t *p_read_req, uint16_t conn_id )
{
    wiced_bt_gatt_status_t status = WICED_BT_GATT_INVALID_HANDLE;
    //printf("ble_app_read_handler function\r\n");
    /* Attempt to perform the Read Request */
    status = ble_app_get_value(p_read_req->handle, conn_id, p_read_req->p_val, *p_read_req->p_val_len, p_read_req->p_val_len);
    printf("Value = %d red by conn_id = %d\r\n",*p_read_req->p_val, conn_id);
    return status;
}

/**************************************************************************************************
* Function Name: ble_app_connect_callback()
***************************************************************************************************
* Summary:
*   This callback function handles connection status changes.
*
* Parameters:
*   wiced_bt_gatt_connection_status_t *p_conn_status  : Pointer to data that has connection details
*
* Return:
*  wiced_bt_gatt_status_t: See possible status codes in wiced_bt_gatt_status_e in wiced_bt_gatt.h
*
**************************************************************************************************/
static wiced_bt_gatt_status_t ble_app_connect_callback(wiced_bt_gatt_connection_status_t *p_conn_status)
{
    wiced_bt_gatt_status_t status = WICED_BT_GATT_ERROR;
    wiced_result_t result = WICED_BT_SUCCESS;
    wiced_bt_gatt_discovery_param_t gatt_discovery_setup = {0};
    //printf("ble_app_connect_callback function\r\n");
    if ( NULL != p_conn_status )
    {
/*******************************server code************************************************/
    	if ( (p_conn_status->connected) && (memcmp(p_conn_status->bd_addr, (uint8_t *)EnvControl, 6) == 0))
        {
            /* Device has connected */
            printf("Connected to EnvControl Client: BD Addr: " );
            print_bd_address(p_conn_status->bd_addr);
            printf("Connection to EnvControl Client ID '%d'\n", p_conn_status->conn_id );

            /* Store the connection ID */
            bt_connection_id_envcontrol = p_conn_status->conn_id;

        }
//        else
//        {
//            /* Device has disconnected */
//            printf("\nDisconnected to EnvControl Client: BD Addr: " );
//            print_bd_address(p_conn_status->bd_addr);
//            printf("Connection to EnvControl Client ID '%d', Reason '%s'\n", p_conn_status->conn_id, get_bt_gatt_disconn_reason_name(p_conn_status->reason) );
//
//            /* Set the connection id to zero to indicate disconnected state */
//            bt_connection_id_envcontrol = 0;
//
//            /*restart the scan*/
//            result = wiced_bt_ble_scan(BTM_BLE_SCAN_TYPE_HIGH_DUTY, WICED_TRUE, ctss_scan_result_cback);
//            if(WICED_BT_PENDING != result)
//            {
//                printf("Cannot restart scanning. Error: %d \n", result);
//            }
//            else
//            {
//                printf("\r\nScanning.....\n");
//            }
//        }
 /************************client code****************************************/
    else if ((p_conn_status->connected) && (memcmp(p_conn_status->bd_addr, (uint8_t *)EnvSense, 6) == 0) )
        {
            /* Device has connected */
            printf("Connected to EnvSense Server: BDA " );
            print_bd_address(p_conn_status->bd_addr);
            printf("Connection to EnvSense Server ID '%d'\n", p_conn_status->conn_id );

            /* Store the connection ID */
            bt_connection_id_envsense = p_conn_status->conn_id;

            /* Update the adv/conn state */
            app_bt_adv_conn_state = APP_BT_ADV_OFF_CONN_ON;

            /* Send GATT service discovery request */
            gatt_discovery_setup.s_handle = 1;
            gatt_discovery_setup.e_handle = 0xFFFF;
            gatt_discovery_setup.uuid.len = ENVSENSE_SERVICE_UUID_LEN;
            gatt_discovery_setup.uuid.uu.uuid16 = ENVSENSE_SERVICE_UUID;

            if(WICED_BT_GATT_SUCCESS != (status = wiced_bt_gatt_send_discover(
                                                 bt_connection_id_envsense,
                                                 GATT_DISCOVER_SERVICES_BY_UUID,
                                                 &gatt_discovery_setup)))
            {
                printf("GATT Discovery request failed. Error code: %d, Conn id: %d\n", status, bt_connection_id_envsense);
            }
        }
        else
        {
            /* Device has disconnected */
            printf("Disconnected to EnvSense Server: BDA " );
            print_bd_address(p_conn_status->bd_addr);
            printf("Connection to EnvSense Server ID '%d', Reason '%s'\n", p_conn_status->conn_id, get_bt_gatt_disconn_reason_name(p_conn_status->reason) );

            /* Set the connection id to zero to indicate disconnected state */
            bt_connection_id_envsense = 0;

            /* Reset the flags */
            envsense_service_found = false;
            /* Restart the advertisements */
            result = wiced_bt_start_advertisements(BTM_BLE_ADVERT_UNDIRECTED_HIGH, 0, NULL);
            if(WICED_BT_SUCCESS != result)
            {
                printf("Advertisement cannot start because of error: %d \n",result);
                CY_ASSERT(0);
            }

            /* Update the adv/conn state */
            app_bt_adv_conn_state = APP_BT_ADV_ON_CONN_OFF;

        }

        /* Update Advertisement LED to reflect the updated state */
        adv_led_update();
/******************************************************************************************/
    	status = WICED_BT_GATT_SUCCESS;
    }

    return status;
}

/**************************************************************************************************
* Function Name: ble_app_server_callback()
***************************************************************************************************
* Summary:
*   This function handles GATT server events from the BT stack.
*
* Parameters:
*   uint16_t conn_id                            : Connection ID
*   wiced_bt_gatt_request_type_t type           : Type of GATT server event
*   wiced_bt_gatt_request_data_t *p_data        : Pointer to GATT server event data
*
* Return:
*  wiced_bt_gatt_status_t: See possible status codes in wiced_bt_gatt_status_e in wiced_bt_gatt.h
*
**************************************************************************************************/
static wiced_bt_gatt_status_t ble_app_server_callback(uint16_t conn_id, wiced_bt_gatt_request_type_t type, wiced_bt_gatt_request_data_t *p_data)
{
    wiced_bt_gatt_status_t status = WICED_BT_GATT_ERROR;
    //printf("ble_app_server_callback! function\r\n");

    switch ( type )
    {
        case GATTS_REQ_TYPE_READ:
            /* Attribute read request */
            //printf("Attribute read request\r\n");
            status = ble_app_read_handler( &p_data->read_req, conn_id );
            break;

        case GATTS_REQ_TYPE_WRITE:
            /* Attribute write request */
            //printf("Attribute write request\r\n");
            status = ble_app_write_handler( &p_data->write_req, conn_id );
            break;
    }

    return status;
}

/*********************************************************************
* Function Name: static void ctss_send_notification()
**********************************************************************
* Summary:
*   Send GATT notification every millisecond.
*
* Parameters:
*   None
*
* Return:
*   None
*
**********************************************************************/

static void send_notification(void)
{
    wiced_bt_gatt_status_t status = WICED_BT_GATT_SUCCESS;
    //printf("ctss_send_notification! function\r\n");

    app_envcontrol_controlposition[0]= curKnobPos;
    app_envcontrol_controlposition[1]= 0x00;
//    app_envcontrol_controlposition[0]= (uint8_t) (vw.servoPosition_v10 & 0xFF);
//    app_envcontrol_controlposition[1]= (uint8_t) ((vw.servoPosition_v10) >> 8);
	app_envcontrol_controlposition[2]= vw.humiState_v11;
	app_envcontrol_controlposition[3]= vw.modeInd_v12;

    status = wiced_bt_gatt_send_notification(bt_connection_id_envcontrol,
    											HDLC_ENVCONTROL_CONTROLPOSITION_VALUE,
												app_envcontrol_controlposition_len,
												app_envcontrol_controlposition);

    if (WICED_BT_GATT_SUCCESS != status)
    {
        printf("Send notification failed\n");
    }
    else
    {
//        printf("EnvControl notify data cP = %d,  hF = %d,  mI = %d\r\n\r\n",*app_envcontrol_controlposition,
//        		app_envcontrol_controlposition[2],app_envcontrol_controlposition[3]
//        );
    }

}

/****************************************************************************
* Function Name: void ctss_app_msec_timer_cb()
*****************************************************************************
* Summary:
*   Millisecond timer callback.
*   Send GATT notifications if enabled by the GATT Client.
*
* Parameters:
*   timer_handle :  Software timers are reference variable.
*
* Return:
*   None
*
****************************************************************************/

static void app_msec_timer_cb(TimerHandle_t timer_handle)
{
    if (app_envcontrol_controlposition_client_char_config[0])
    {
        /* sending GATT notification. */
        send_notification();
    }

    uint8_t vwNo[] = {0,3,8,9,10,11,12}; // Auto
    uint8_t vwNoM[] = {0,3,0,3,10,11,12}; // Manual
    uint8_t vwInit[] = {_tempMin,_tempMax,_humiMin,_humiMax,_modeSet,_setHeater,_setHumiState,completed};
	uint8_t datalen,headerlen,i;
	static uint8_t vw_no=0;

	if((blynkState == connected) && (blynkInit == completed))
	{
		ph.cmd = BLYNK_CMD_HARDWARE;//BLYNK_CMD_PING;
		++secCnt; //increment 1 secCnt counter
		for(i=0; i < sizeof(vwNo); i++)
		{
			ph.msg_id = getMsgId();
			u1._2byte = ph.msg_id;
			if(vw.modeSetManual_v6 == 11)vw_no = vwNoM[i];
			else vw_no = vwNo[i];
    		switch(vw_no)
    		{
    			case 0:
    					datalen = data4byte(0,vw.tempRead_v0); // current temp
    				break;
    			case 3:
    					datalen = data4byte(3,vw.humiRead_v3); // current humidity
    				break;
    			case 8:
//    					datalen = data1byte(8,vw.servoPositionManual_v8);
    					datalen = data1byte(8,curKnobPos); // knob position to be set
    				break;
    			case 9:
    					datalen = data1byte(9,vw.humiStateManual_v9);
    				break;
    			case 10:
//    					datalen = data1byte(10,vw.servoPosition_v10);
    					datalen = data1byte(10,curKnobPos); // knob position to be set
    				break;
    			case 11:
    					datalen = data1byte(11,vw.humiState_v11); // humidifier state
    				break;
    			case 12:
    					datalen = data1byte(12,vw.modeInd_v12); // current mode
    				break;
    			default: vw_no = 0;
    				break;
    		}
        	    headerlen = header(ph.cmd,u1.ch[1],u1.ch[0],0,datalen);
    			memcpy(&ph.tx_Frame[headerlen],virtualvalue,datalen);
    			ph.msg_len = datalen+headerlen;
    			tcp_client_sent_handler(client_handle, NULL);
		}
	}
	else if((blynkState == connected) ||(blynkInit ==  _hwLogin))
	{
		if(blynkInit ==  _hwLogin)ph.cmd = BLYNK_CMD_HW_LOGIN;
		else ph.cmd = BLYNK_CMD_HARDWARE;//BLYNK_CMD_PING;
		ph.msg_id = getMsgId();
		u1._2byte = ph.msg_id;

		if(blynkInit ==  _hwLogin)
		{
			ph.msg_len = hwLogin(ph.cmd,u1.ch[1],u1.ch[0],0,32,auth);
			tcp_client_sent_handler(client_handle, NULL);
		}
		else
		{
			for(i=0; i < sizeof(vwInit); i++)
			{
				blynkInit = vwInit[i];
				switch(blynkInit)
				{
    				case _tempMin:
    					datalen = data1byte(1,vw.tempMin_v1);
    				break;
    				case _tempMax:
    					datalen = data1byte(2,vw.tempMax_v2);
    				break;
    				case _humiMin:
    					datalen = data1byte(4,vw.humiMin_v4);
    				break;
    				case _humiMax:
    					datalen = data1byte(5,vw.humiMax_v5);
    				break;
    				case _modeSet:
    					datalen = data1byte(6,vw.modeSetManual_v6);
    				break;
    				case _setHeater:
    					datalen = data1byte(8,vw.servoPositionManual_v8);
    				break;
    				case _setHumiState:
    					datalen = data1byte(9,vw.humiStateManual_v9);
    				break;
    				default: blynkInit = completed;
    				break;
				}
    			headerlen = header(ph.cmd,u1.ch[1],u1.ch[0],0,datalen);
    			memcpy(&ph.tx_Frame[headerlen],virtualvalue,datalen);
    			ph.msg_len = datalen+headerlen;
    			tcp_client_sent_handler(client_handle, NULL);
			}
		}
	}
}

/*************************************************************************************
* Function Name: gatt_db_lookup_table_t* ctss_get_attribute()
**************************************************************************************
* Summary: Find attribute description by handle
*
* Parameters:
*   uint16_t handle: Attribute handle
*
* Return:
*   gatt_db_lookup_table_t*: Pointer to BLE GATT attribute handle
*
*************************************************************************************/
gatt_db_lookup_table_t* get_attribute(uint16_t handle)
{
    //printf("ctss_get_attribute! function\r\n");
	for (uint16_t i = 0; i < app_gatt_db_ext_attr_tbl_size; i++)
    {
        if (app_gatt_db_ext_attr_tbl[i].handle == handle)
        {
            return (&app_gatt_db_ext_attr_tbl[i]);
        }
    }

    printf("Attribute not found:%x\n", handle);

    return NULL;
}

/**************************************************************************************************
* Function Name: ble_app_set_advertisement_data()
***************************************************************************************************
* Summary:
*   This function configures the advertisement packet data
*
**************************************************************************************************/
static void ble_app_set_advertisement_data(void)
{
    wiced_bt_ble_advert_elem_t adv_elem[3] = { 0 };
    //uint8_t adv_flag = BTM_BLE_GENERAL_DISCOVERABLE_FLAG | BTM_BLE_BREDR_NOT_SUPPORTED;
    uint8_t adv_appearance[] = { BIT16_TO_8( APPEARANCE_GENERIC_COMPUTER ) };
    uint8_t num_elem = 0;

//    /* Advertisement Element for Flags */
//    adv_elem[num_elem].advert_type = BTM_BLE_ADVERT_TYPE_FLAG;
//    adv_elem[num_elem].len = sizeof(uint8_t);
//    adv_elem[num_elem].p_data = &adv_flag;
//    num_elem++;
//
//    /* Advertisement Element for Name */
//    adv_elem[num_elem].advert_type = BTM_BLE_ADVERT_TYPE_NAME_COMPLETE;
//    adv_elem[num_elem].len = app_gap_device_name_len;
//    adv_elem[num_elem].p_data = app_gap_device_name;
//    num_elem++;
//
//    /* Advertisement Element for Appearance */
//    adv_elem[num_elem].advert_type = BTM_BLE_ADVERT_TYPE_APPEARANCE;
//    adv_elem[num_elem].len = sizeof(adv_appearance);
//    adv_elem[num_elem].p_data = adv_appearance;
//    num_elem++;

        /* Advertisement Element for Appearance */
        adv_elem[num_elem].advert_type = BTM_BLE_ADVERT_TYPE_SERVICE_DATA;
        adv_elem[num_elem].len = sizeof(adv_appearance);
        adv_elem[num_elem].p_data = adv_appearance;
        num_elem++;

        printf("ble_app_set_advertisement_data! function\n");
    /* Set Raw Advertisement Data */
    wiced_bt_ble_set_raw_advertisement_data(num_elem, adv_elem);
}

/*******************************************************************************
* Function Name: adv_led_update()
********************************************************************************
*
* Summary:
*   This function updates the advertising LED state based on BLE advertising/
*   connection state
*
*******************************************************************************/
static void adv_led_update(void)
{
    cy_rslt_t rslt = CY_RSLT_SUCCESS;
    cy_rslt_t start_rslt = CY_RSLT_SUCCESS;
    /* Stop the advertising led pwm */
    rslt = cyhal_pwm_stop(&adv_led_pwm);
    if (CY_RSLT_SUCCESS != rslt)
    {
        printf("Failed to stop PWM !!\n");
    }

    /* Update LED state based on BLE advertising/connection state.
     * LED OFF for no advertisement/connection, LED blinking for advertisement
     * state, and LED ON for connected state  */
    switch(app_bt_adv_conn_state)
    {
        case APP_BT_ADV_OFF_CONN_OFF:
            rslt = cyhal_pwm_set_duty_cycle(&adv_led_pwm, LED_OFF_DUTY_CYCLE, ADV_LED_PWM_FREQUENCY);
            break;

        case APP_BT_ADV_ON_CONN_OFF:
            rslt = cyhal_pwm_set_duty_cycle(&adv_led_pwm, LED_BLINKING_DUTY_CYCLE, ADV_LED_PWM_FREQUENCY);
            break;

        case APP_BT_ADV_OFF_CONN_ON:
            rslt = cyhal_pwm_set_duty_cycle(&adv_led_pwm, LED_ON_DUTY_CYCLE, ADV_LED_PWM_FREQUENCY);
            break;

        default:
            /* LED OFF for unexpected states */
            rslt = cyhal_pwm_set_duty_cycle(&adv_led_pwm, LED_OFF_DUTY_CYCLE, ADV_LED_PWM_FREQUENCY);
            break;
    }
    /* Check if update to PWM parameters is successful*/
    if (CY_RSLT_SUCCESS != rslt)
    {
        printf("Failed to set duty cycle parameters!!\n");
    }

    /* Start the advertising led pwm */
    start_rslt = cyhal_pwm_start(&adv_led_pwm);

    /* Check if PWM started successfully */
    if (CY_RSLT_SUCCESS != start_rslt)
    {
        printf("Failed to start PWM !!\n");
    }
}

/*****************************************************************************************
* Function Name: enable_gatt_notification()
******************************************************************************************
* Summary:
*   Enable GATT notification from the server.
*
* Parameters:
*   None
*
* Return:
*   wiced_bt_gatt_status_t  : Status code from wiced_bt_gatt_status_e.
*
****************************************************************************************/
static wiced_bt_gatt_status_t enable_gatt_notification(void)
{
    wiced_bt_gatt_value_t      *p_write = NULL;
    wiced_bt_gatt_status_t     status = WICED_BT_GATT_SUCCESS;

    p_write = (wiced_bt_gatt_value_t*)malloc(sizeof(wiced_bt_gatt_value_t) + CCCD_LENGTH);//HARI

    if (p_write)
    {
        memset(p_write, 0, sizeof(wiced_bt_gatt_value_t) + CCCD_LENGTH);
        p_write->handle   = envsense_service_handle + GATT_CCCD_HANDLE;
        p_write->len      = CCCD_LENGTH;
        p_write->value[0] = 1; //1 - enable or 0 - disable notification;

        status = wiced_bt_gatt_send_write(bt_connection_id_envsense, GATT_WRITE, p_write);
        free(p_write);
    }
    return status;
}

/*****************************************************************************************
* Function Name: print_notification_data()
******************************************************************************************
* Summary:
*   Parses the notification data to get date, time and other fields.
*
* Parameters:
*   wiced_bt_gatt_data_t notif_data: Notification packet from GATT server
*
* Return:
*   None
*
****************************************************************************************/
static void print_notification_data(wiced_bt_gatt_data_t notif_data)
{
    humidity = ((float)((notif_data.p_data[1] << 8u) | notif_data.p_data[0])/100);
    temperature = ((float)((notif_data.p_data[3] << 8u) | notif_data.p_data[2])/100);

    vw.tempRead_v0 = temperature;
    vw.humiRead_v3 = humidity;
    if(secCnt >= 2) //check condition on every 10sec
    {
    	check_condition();
    	secCnt = 0;
    }

	//printf("EnvSense notified data Temp = %2.2f,  Humi = %2.2f\r\n\r\n", temperature,humidity);
}

void init_env_param(void)
{
//	float temperature; 				/* v0 */
//	uint8_t tempMin; 				/* v1 */
//	uint8_t tempMax; 				/* v2 */
//	float humidity; 				/* v3 */
//	uint8_t humiMin;				/* v4 */
//	uint8_t humiMax;				/* v5  not used*/
//	uint8_t modeSetManual;			/* v6 */
//	uint8_t save;				    /* v7 */
//	uint8_t servoPositionManual; 	/* v8 */
//	uint8_t humiStateManual;		/* v9 */
//	uint8_t servoPosition;			/* v10 */
//	uint8_t humiState; 				/* v11 */
//	uint8_t modeInd; 				/* v12 */
	if(readEeprom() == 0x00)
	{
		printf("Initialise Saved Blynk details\n");
		vw.tempMin_v1 = blynk_details._tempMin_v1;
		vw.tempMax_v2 = blynk_details._tempMax_v2;
		vw.humiMin_v4 = blynk_details._humiMin_v4;
		vw.humiMax_v5 = blynk_details._humiMax_v5;
		vw.modeSetManual_v6 = blynk_details._prvMode_v12;
		vw.servoPositionManual_v8 = blynk_details._prvPos_v10;
		vw.humiStateManual_v9 = blynk_details._prvState_v11;

	}
	else
	{	/* default blynk values */
		printf("Initialise default Blynk details\n");
		blynk_details._tempMin_v1 = vw.tempMin_v1 = 18;
		blynk_details._tempMax_v2 = vw.tempMax_v2 = 25;
		blynk_details._humiMin_v4 = vw.humiMin_v4 = 30;
		blynk_details._humiMax_v5 = vw.humiMax_v5 = 50; // not used

		blynk_details._prvMode_v12 = vw.modeSetManual_v6 = 10;
		blynk_details._prvState_v11 = vw.humiStateManual_v9 = 10;
		blynk_details._prvPos_v10 = vw.servoPositionManual_v8 = 10;
	}
	vw.servoPosition_v10 = vw.servoPositionManual_v8;
	vw.humiState_v11 = vw.humiStateManual_v9;
	vw.modeInd_v12 = vw.modeSetManual_v6;
	prvKnobPos = vw.servoPosition_v10;
	curKnobPos = prvKnobPos;
}

void check_condition(void)
{
	if(vw.modeSetManual_v6 == 10)
	{
		if((vw.tempRead_v0 < vw.tempMin_v1))
		{
			if((vw.servoPosition_v10 >= 10) && (vw.servoPosition_v10 < 15))
			{
				vw.servoPosition_v10 += 1;// increment knob by one position step
			}
			vw.servoPositionManual_v8 = vw.servoPosition_v10;
			curKnobPos = vw.servoPosition_v10;
			prvKnobPos = curKnobPos;
		}
		else if ((vw.tempRead_v0 > vw.tempMax_v2))
		{
			if((vw.servoPosition_v10 > 10) && (vw.servoPosition_v10 <= 15))
			{
				vw.servoPosition_v10 -= 1;// set servo position
			}
			vw.servoPositionManual_v8 = vw.servoPosition_v10;
			curKnobPos = vw.servoPosition_v10;
			prvKnobPos = curKnobPos;
		}
//		else if((vw.tempRead_v0 > vw.tempMin_v1) && (vw.tempRead_v0 < vw.tempMax_v2))
		else
		{
			// keep knob position same
			curKnobPos = prvKnobPos;
		}
		if(vw.humiRead_v3 < vw.humiMin_v4)
		{
			vw.humiState_v11 = 11;// turn on humidifier
			vw.humiStateManual_v9 = 11;
		}
		else
		{
			vw.humiState_v11 = 10;// turn off humidifier
			vw.humiStateManual_v9 = 10;
		}
//		else if(vw.humiRead_v3 > vw.humiMax_v5)
//		{
//			vw.humiState_v11 = 10;// turn off humidifier
//			vw.humiStateManual_v9 = 10;
//		}
	}
	else
	{
		vw.servoPosition_v10 = vw.servoPositionManual_v8;
		curKnobPos = vw.servoPositionManual_v8;
		vw.humiState_v11 = vw.humiStateManual_v9;
	}
}

/* [] END OF FILE */
